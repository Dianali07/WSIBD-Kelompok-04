/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package New_design;

import java.awt.Color;
import Form_tabel.DataPendaftaran;
import Login.Koneksi;
import java.awt.Color;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import static org.codehaus.groovy.tools.shell.Main.setColor;
import static org.codehaus.groovy.tools.shell.util.Preferences.clear;

import Login.Koneksi;
import Login.Login;
import static java.awt.image.ImageObserver.WIDTH;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ADAM
 */
public class FormDasboard_user extends javax.swing.JFrame {
    int dragxmouse;
    int dragymouse;
    Koneksi koneksi = new Koneksi();

    private DefaultTableModel model;
    
    
    
       public void loadData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM ekskul";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[6];
                
                o [0] = r.getString("nama_ekskul");
                o [1] = r.getString("penanggung_jawab");
                o [2] = r.getString("lokasi");
                o [3] = r.getString("hari");
                o [4] = r.getString("jam_mulai");
                o [5] = r.getString("jam_selesai");
               
                
            
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        FormDasboard f2 = new FormDasboard();
        
        setVisible(true);
        jTable2.setModel(model);
        
        int  c = model.getRowCount();
        
        f2.txId1.setText(""+c);
        setVisible(true);
    } 
      public void loadData4(){
         model.getDataVector().removeAllElements();
         model.fireTableDataChanged();
         
         try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT ekskul.nama_ekskul,ekskul.lokasi,ekskul.hari,ekskul.jam_mulai,ekskul.jam_selesai,registrasi.tanggal_daftar,siswa.nama_siswa\n" +
" FROM registrasi JOIN ekskul on registrasi.id_ekskul = ekskul.id_ekskul JOIN siswa ON registrasi.id_siswa = siswa.id_siswa ";;
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[4];
                o [0]= r.getString("nama_siswa");
                o [1] = r.getString("nama_ekskul");
                o [2] = r.getString("lokasi");
                o [3] = r.getString("tanggal_daftar");
                
                
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        int b = model.getRowCount();
        //txId1.setText(""+b);
        setVisible(true);
        jTable1.setModel(model);
         
    }  /* "SELECT ekskul.nama_ekskul,ekskul.lokasi,ekskul.hari,ekskul.jam_mulai,ekskul"
                    + ".jam_selesai,registrasi.tanggal_daftar FROM registrasi JOIN ekskul on registrasi.id_ekskul = ekskul.id_ekskul\n" +
                        "JOIN siswa ON registrasi.id_siswa = siswa.id_siswa";*/
      
    public void Nama(){
         try {
                Connection c = Koneksi.getKoneksi();
                Statement s = c.createStatement();
                String sql = "SELECT * FROM yu.siswa";
                
                ResultSet r = s.executeQuery(sql);
                
                    while(r.next()) {
                        //cbNis.addItem((r.getString(2)));
                        //IDnya = r.getString(1);
                        
                        
                    }
                    
                    
                    r.close();
                    s.close();
                        } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, ex, ex.getMessage(), WIDTH, null);
                        }
    
    }
     public void clear(){
        //txNama.setText("");
        //txHarga.setText("");
        
    }       
    /**
     * Creates new form DataPendaftaran
     */
    public FormDasboard_user() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        
        
        model = new DefaultTableModel();
        
        jTable1.setModel(model);
        model.addColumn("nama siswa");
        model.addColumn("nama ekskul ");
        model.addColumn("lokasi ");
        model.addColumn("tanggal daftar");
        
        
        loadData4();
        //autonumber();
        model = new DefaultTableModel();
        
        jTable2.setModel(model);
        
        
        model.addColumn("Nama Ekstrakurikuler");
        model.addColumn("Penanggung jawab");
        model.addColumn("Lokasi Ekskul");
        model.addColumn("Hari");
        model.addColumn("Jam Mulai");
        model.addColumn("Jam Selesai");
        
        loadData();
        
    }
       
    private void autonumber(){
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            String sql = "SELECT * FROM nama_terdaftar ORDER BY id DESC";
            ResultSet r = s.executeQuery(sql);
            if (r.next()){
                String NoDaftar = r.getString("id").substring(2);
                String DR = "" + (Integer.parseInt(NoDaftar) + 1);  
                String Nol = "";
                
                if(DR.length()==1){
                    Nol = "00";
                }else if(DR.length()==2){
                    Nol = "0";
                }else if(DR.length()==3){
                    Nol = "";
                }
                
                //txId.setText("BR" + Nol + DR);
                
            }else{
               // txId.setText("DR001");
            }
            r.close();
            s.close();
        }catch(Exception e){
            System.out.println("autonumber error");
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        sidepane = new javax.swing.JPanel();
        ha1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        Dashboard = new javax.swing.JPanel();
        dashboard = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidepane.setBackground(new java.awt.Color(51, 51, 51));
        sidepane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ha1.setBackground(new java.awt.Color(60, 60, 60));
        ha1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha1MousePressed(evt);
            }
        });
        ha1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-home-15 (1).png"))); // NOI18N
        ha1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 0, 34, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Dashboard");
        ha1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, 74, 24));

        sidepane.add(ha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 260, 50));
        sidepane.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 220, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/2-removebg-preview.png"))); // NOI18N
        sidepane.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SMAN 1 PESANGGARAN");
        sidepane.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 170, 28));

        bg.add(sidepane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 656));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-xbox-x-30.png"))); // NOI18N
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        bg.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 20, -1, -1));

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setLayout(new java.awt.CardLayout());

        Dashboard.setBackground(new java.awt.Color(255, 255, 255));
        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Data Pendaftar Ekskul");
        dashboard.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 24, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        dashboard.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 700, 170));

        Dashboard.add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 740, 300));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setText("Ekstrakurikuler");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        jLabel3.setText("User / Registrasi Ekskul");

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButton1.setText("Daftar");
        jButton1.setBorder(null);
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 716, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel12))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel12)
                .addGap(3, 3, 3)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                .addContainerGap())
        );

        Dashboard.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 740, 260));

        mainPanel.add(Dashboard, "card2");

        bg.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 780, 590));

        jLabel11.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel11MouseDragged(evt);
            }
        });
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel11MousePressed(evt);
            }
        });
        bg.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 660));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        bg.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1035, 656));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
       this.dispose();
       ClassLogin a = new ClassLogin();
       a.setVisible(true);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void ha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MousePressed
        // TODO add your handling code here:
        
       // setColor(ha1);
        //resetColor(ha2);
        
    }//GEN-LAST:event_ha1MousePressed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel11MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MousePressed
        // TODO add your handling code here:
            dragxmouse = evt.getX();
            dragymouse = evt.getY();
    }//GEN-LAST:event_jLabel11MousePressed

    private void jLabel11MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseDragged
        // TODO add your handling code here:
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
         
         this.setLocation(x - dragxmouse,y- dragymouse );
         System.out.println(x+""+y);
         
    }//GEN-LAST:event_jLabel11MouseDragged

    private void ha1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseEntered
        // TODO add your handling code here:
        setColor(ha1);
        
    }//GEN-LAST:event_ha1MouseEntered

    private void ha1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseExited
        // TODO add your handling code here:
        resetColor(ha1);
        
    }//GEN-LAST:event_ha1MouseExited

    private void ha1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseClicked
        // TODO add your handling code here:
        setColor2(ha1);
        
        //remove panel
       
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();
        
        //addpanel
        mainPanel.add(Dashboard);
        mainPanel.repaint();
        mainPanel.revalidate();
        setColor2(ha1);
        
    }//GEN-LAST:event_ha1MouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
           this.dispose();
         FormDasboard_user1 fk  = new  FormDasboard_user1();
         fk.setVisible(true);
         
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    void setColor(JPanel panel){
        panel.setBackground(new Color(204,204,204));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    
    void setColor2(JPanel panel){
        panel.setBackground(new Color(102,153,255));
    }
    void resetColor2(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormDasboard_user().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel bg;
    private javax.swing.JPanel dashboard;
    private javax.swing.JPanel ha1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel sidepane;
    // End of variables declaration//GEN-END:variables
}
