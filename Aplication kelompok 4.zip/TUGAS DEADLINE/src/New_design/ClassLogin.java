/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package New_design;

/**
 *
 * @author ADAM
 */
public class ClassLogin {
     public static void main(String []args){
         Fromlogin A = new Fromlogin();
         A.setVisible(true);
     }

    void setVisible(boolean b) {
       Fromlogin A = new Fromlogin();
         A.setVisible(true);
    }
}
