/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package New_design;



import Login.Koneksi;
import Login.Login;
import groovyjarjarcommonscli.ParseException;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ADAM
 */
public class FormDasboard3 extends javax.swing.JFrame {
    int dragxmouse;
    int dragymouse;
    Koneksi koneksi = new Koneksi();
    private DefaultTableModel model;
    

    
    
    
      
    public void loadData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM ekskul";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[6];
                
                o [0] = r.getString("nama_ekskul");
                o [1] = r.getString("penanggung_jawab");
                o [2] = r.getString("lokasi");
                o [3] = r.getString("hari");
                o [4] = r.getString("jam_mulai");
                o [5] = r.getString("jam_selesai");
               
                
            
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        FormDasboard f2 = new FormDasboard();
        
        setVisible(true);
        jTable3.setModel(model);
        
        int  c = model.getRowCount();
        
        f2.txId1.setText(""+c);
        setVisible(true);
    } 
    
    //public static Date getTanggalFromTable(JTable table, int kolom)
    {
      /*  JTable tabel = table;
        String str_tgl = String.valueOf(tabel.getValueAt(tabel.getSelectedRow(), kolom));
        Date tanggal = null;
        try {
            tanggal =  new SimpleDateFormat("yyyy-MM-dd").parse(str_tgl);
            
        } catch (java.text.ParseException ex) {
            Logger.getLogger(FormDasboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tanggal;
    }   
     */
        
    }    
     public void clear(){
         
        
        txNama.setText("");
        txPenanggung.setText("");
        txLokasi.setText("");
        cbHari.setSelectedIndex(0);
        cbJammulai.setSelectedIndex(0);
        cbJamselesai.setSelectedIndex(0);
        
    }    
    /**
     * Creates new form DataPendaftaran
     */
    public FormDasboard3() {
        initComponents();
        this.setLocationRelativeTo(null);
        //txId.setEnabled(false);
       
        model = new DefaultTableModel();
        
        jTable3.setModel(model);
        
        
        model.addColumn("Nama Ekstrakurikuler");
        model.addColumn("Penanggung jawab");
        model.addColumn("Lokasi Ekskul");
        model.addColumn("Hari");
        model.addColumn("Jam Mulai");
        model.addColumn("Jam Selesai");
        
        loadData();
        
       
    }
     public Connection conn;
     
    
       
    private void autonumber(){
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            String sql = "SELECT * FROM nama_terdaftar ORDER BY id DESC";
            ResultSet r = s.executeQuery(sql);
            if (r.next()){
                String NoDaftar = r.getString("id").substring(2);
                String DR = "" + (Integer.parseInt(NoDaftar) + 1);  
                String Nol = "";
                
                if(DR.length()==1){
                    Nol = "00";
                }else if(DR.length()==2){
                    Nol = "0";
                }else if(DR.length()==3){
                    Nol = "";
                }
                
                //txId.setText("BR" + Nol + DR);
                
            }else{
               // txId.setText("DR001");
            }
            r.close();
            s.close();
        }catch(Exception e){
            System.out.println("autonumber error");
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        sidepane = new javax.swing.JPanel();
        ha1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ha2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ha3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        ha4 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        Data_Ekstrakurikuler = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        txCari2 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txNama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txPenanggung = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txLokasi = new javax.swing.JTextField();
        tx1 = new javax.swing.JLabel();
        cbHari = new javax.swing.JComboBox<>();
        cbJammulai = new javax.swing.JComboBox<>();
        tx2 = new javax.swing.JLabel();
        cbJamselesai = new javax.swing.JComboBox<>();
        tx3 = new javax.swing.JLabel();
        btnSimpan1 = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnBatal = new javax.swing.JButton();
        btnBatal1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidepane.setBackground(new java.awt.Color(51, 51, 51));
        sidepane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ha1.setBackground(new java.awt.Color(60, 60, 60));
        ha1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha1MousePressed(evt);
            }
        });
        ha1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-home-15 (1).png"))); // NOI18N
        ha1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 0, 34, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Dashboard");
        ha1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, 74, 24));

        sidepane.add(ha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 260, 50));

        ha2.setBackground(new java.awt.Color(60, 60, 60));
        ha2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha2MousePressed(evt);
            }
        });
        ha2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-group-15.png"))); // NOI18N
        ha2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Data Siswa");
        ha2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 260, 60));

        ha3.setBackground(new java.awt.Color(60, 60, 60));
        ha3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha3MousePressed(evt);
            }
        });
        ha3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-user-male-15.png"))); // NOI18N
        ha3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Data Pengguna");
        ha3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 260, 60));

        ha4.setBackground(new java.awt.Color(60, 60, 60));
        ha4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha4MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha4MousePressed(evt);
            }
        });
        ha4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-price-tag-15.png"))); // NOI18N
        ha4.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 20, 60));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Data Ekstrakurikuler");
        ha4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 260, 60));
        sidepane.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 220, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/2-removebg-preview.png"))); // NOI18N
        sidepane.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SMAN 1 PESANGGARAN");
        sidepane.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 170, 28));

        bg.add(sidepane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 656));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-xbox-x-30.png"))); // NOI18N
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        bg.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 20, -1, -1));

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setLayout(new java.awt.CardLayout());

        Data_Ekstrakurikuler.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setPreferredSize(new java.awt.Dimension(716, 438));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setText("Kelola Ekskul");

        jLabel27.setText("Admin / Data Ekstrakurikuler");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);

        txCari2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txCari2ActionPerformed(evt);
            }
        });
        txCari2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txCari2KeyTyped(evt);
            }
        });

        jLabel35.setText("Cari Data");

        jLabel5.setText("Nama Ekstra");

        jLabel6.setText("Nama penanggung jawab");

        jLabel10.setText("Lokasi");

        tx1.setText("Hari");

        cbHari.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu", "Minggu" }));

        cbJammulai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00:00:00", "00:30:00", "01:00:00", "01:30:00", "02:00:00", "02:30:00", "03:00:00", "03:30:00", "04:00:00", "04:30:00", "05:00:00", "05:30:00", "06:00:00", "06:30:00", "07:00:00", "07:30:00", "08:00:00", "08:30:00", "09:00:00", "09:30:00", "10:00:00", "10:30:00", "11:00:00", "11:30:00", "12:00:00", "12:30:00", "13:00:00", "13:30:00", "14:00:00", "14:30:00", "15:00:00", "15:30:00", "16:00:00", "16:30:00", "17:00:00", "17:30:00", "18:00:00", "18:30:00", "19:00:00", "19:30:00", "20:00:00", "20:30:00", "21:00:00", "21:30:00", "22:00:00", "22:30:00", "23:00:00", "23:30:00" }));
        cbJammulai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbJammulaiActionPerformed(evt);
            }
        });

        tx2.setText("Jam Mulai");

        cbJamselesai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00:00:00", "00:30:00", "01:00:00", "01:30:00", "02:00:00", "02:30:00", "03:00:00", "03:30:00", "04:00:00", "04:30:00", "05:00:00", "05:30:00", "06:00:00", "06:30:00", "07:00:00", "07:30:00", "08:00:00", "08:30:00", "09:00:00", "09:30:00", "10:00:00", "10:30:00", "11:00:00", "11:30:00", "12:00:00", "12:30:00", "13:00:00", "13:30:00", "14:00:00", "14:30:00", "15:00:00", "15:30:00", "16:00:00", "16:30:00", "17:00:00", "17:30:00", "18:00:00", "18:30:00", "19:00:00", "19:30:00", "20:00:00", "20:30:00", "21:00:00", "21:30:00", "22:00:00", "22:30:00", "23:00:00", "23:30:00" }));

        tx3.setText("Jam Selesai");

        btnSimpan1.setText("Simpan");
        btnSimpan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpan1ActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });

        btnBatal1.setText("Data Pendaftar");
        btnBatal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatal1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnSimpan1)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete)
                        .addGap(101, 101, 101)
                        .addComponent(btnBatal)
                        .addGap(38, 38, 38)
                        .addComponent(btnBatal1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(txLokasi)
                                .addGap(285, 285, 285)
                                .addComponent(jLabel35)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txCari2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel26)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txPenanggung, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txNama, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel27, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel10))
                                .addGap(48, 48, 48)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tx3)
                                    .addComponent(tx2)
                                    .addComponent(tx1)
                                    .addComponent(cbHari, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbJammulai, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbJamselesai, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(28, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tx1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbHari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tx2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txPenanggung, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbJammulai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tx3)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel35)
                        .addComponent(txLokasi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cbJamselesai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txCari2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSimpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBatal1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10))
        );

        javax.swing.GroupLayout Data_EkstrakurikulerLayout = new javax.swing.GroupLayout(Data_Ekstrakurikuler);
        Data_Ekstrakurikuler.setLayout(Data_EkstrakurikulerLayout);
        Data_EkstrakurikulerLayout.setHorizontalGroup(
            Data_EkstrakurikulerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_EkstrakurikulerLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );
        Data_EkstrakurikulerLayout.setVerticalGroup(
            Data_EkstrakurikulerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_EkstrakurikulerLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 54, Short.MAX_VALUE))
        );

        mainPanel.add(Data_Ekstrakurikuler, "card5");

        bg.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 780, 590));

        jLabel11.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel11MouseDragged(evt);
            }
        });
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel11MousePressed(evt);
            }
        });
        bg.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1035, 656));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
       this.dispose();
       ClassLogin a = new ClassLogin();
       a.setVisible(true);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void ha2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MousePressed
        // TODO add your handling code here:
        //setColor(ha2);
        //resetColor(ha1);
    }//GEN-LAST:event_ha2MousePressed

    private void ha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MousePressed
        // TODO add your handling code here:
        
       // setColor(ha1);
        //resetColor(ha2);
        
    }//GEN-LAST:event_ha1MousePressed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel11MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MousePressed
        // TODO add your handling code here:
            dragxmouse = evt.getX();
            dragymouse = evt.getY();
    }//GEN-LAST:event_jLabel11MousePressed

    private void jLabel11MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseDragged
        // TODO add your handling code here:
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
         
         this.setLocation(x - dragxmouse,y- dragymouse );
         System.out.println(x+""+y);
         
    }//GEN-LAST:event_jLabel11MouseDragged

    private void ha1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseEntered
        // TODO add your handling code here:
        setColor(ha1);
        
    }//GEN-LAST:event_ha1MouseEntered

    private void ha1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseExited
        // TODO add your handling code here:
        resetColor(ha1);
        
    }//GEN-LAST:event_ha1MouseExited

    private void ha2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseEntered
        setColor(ha2);
    }//GEN-LAST:event_ha2MouseEntered

    private void ha2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseExited
        resetColor(ha2);
    }//GEN-LAST:event_ha2MouseExited

    private void ha1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseClicked
        // TODO add your handling code here:
        setColor2(ha1);
        resetColor2(ha2);
        //remove panel
        this.dispose();
        FormDasboard a = new FormDasboard();
        a.setVisible(true);
         
        setColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha1MouseClicked

    private void ha2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseClicked
        // TODO add your handling code here:
         //remove panel
        this.dispose();
        FormDasboard1 b = new FormDasboard1();
        b.setVisible(true);
        setColor2(ha2);
        resetColor2(ha1);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha2MouseClicked

    private void ha3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseClicked
        // TODO add your handling code here:
        this.dispose();
        FormDasboard2 c = new FormDasboard2();
        c.setVisible(true);
        setColor2(ha3);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha4);
    }//GEN-LAST:event_ha3MouseClicked

    private void ha3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseEntered
        // TODO add your handling code here:
        setColor(ha3);
    }//GEN-LAST:event_ha3MouseEntered

    private void ha3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseExited
        // TODO add your handling code here:
        resetColor(ha3);
    }//GEN-LAST:event_ha3MouseExited

    private void ha3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MousePressed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_ha3MousePressed

    private void ha4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseClicked
        
        setColor2(ha4);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha3);
        
    }//GEN-LAST:event_ha4MouseClicked

    private void ha4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseEntered
        // TODO add your handling code here:
        setColor(ha4);
    }//GEN-LAST:event_ha4MouseEntered

    private void ha4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseExited
        // TODO add your handling code here:
        resetColor(ha4);
    }//GEN-LAST:event_ha4MouseExited

    private void ha4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_ha4MousePressed

    private void txCari2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txCari2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txCari2ActionPerformed

    private void txCari2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txCari2KeyTyped
        // TODO add your handling code here:
        DefaultTableModel tabel2 = new DefaultTableModel();

        tabel2.addColumn("Nama Ekstrakurikuler");
        tabel2.addColumn("Penanggung jawab");
        tabel2.addColumn("Lokasi Ekskul");
        tabel2.addColumn("Hari");
        tabel2.addColumn("Jam Mulai");
        tabel2.addColumn("Jam Selesai");
        

        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "Select * from ekskul where nama_ekskul like '%" + txCari2.getText() + "%'";
            Statement stat = c.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while(rs.next()){
                tabel2.addRow(new Object[]{
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    
                });
            }
            jTable3.setModel(tabel2);
            
        }catch(Exception e){
            System.out.println("Cari Data Error");
        }finally{
        }
    }//GEN-LAST:event_txCari2KeyTyped

    private void btnSimpan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpan1ActionPerformed
        // TODO add your handling code here:
        String id_ekskul = null;
        String jam_selesai = (String) cbJamselesai.getSelectedItem();
        String nama_ekskul = txNama.getText().toString().trim();
        String penanggung_jawab = txPenanggung.getText().toString().trim();
        String lokasi = txLokasi.getText().toString().trim();
        String hari = (String) cbHari.getSelectedItem();
        String jam_mulai = (String) cbJammulai.getSelectedItem();
        
            try{
                Connection c = Koneksi.getKoneksi();
                String sql ="INSERT INTO ekskul VALUES (?,?,?,?,?,?,?)";
                PreparedStatement p = c.prepareStatement(sql);
                p.setString(1, id_ekskul);
                p.setString(2, nama_ekskul);
                p.setString(3, penanggung_jawab);
                p.setString(4, lokasi);
                p.setString(5, hari);
                p.setString(6, jam_mulai);
                p.setString(7, jam_selesai);
                p.executeUpdate();
                p.close();
                JOptionPane.showMessageDialog(null, "Masukkan data ekstra success");

            }catch(SQLException e){
                System.out.println("Error");
            }finally{
                clear();
                loadData();
                jTable3.setModel(model);
            }
        
    }//GEN-LAST:event_btnSimpan1ActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
        int i = jTable3.getSelectedRow();
        if(i == -1){
            return;
        }

        String nama_ekskul = (String)model.getValueAt(i, 0);
        txNama.setText(nama_ekskul);

        int question = JOptionPane.showConfirmDialog(null, "Yakin Data Akan Dihapus?","Konfirmasi", JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        if(question == JOptionPane.OK_OPTION){
            try{
                Connection c = Koneksi.getKoneksi();
                String sql = "DELETE FROM ekskul WHERE nama_ekskul = ?";
                PreparedStatement p = c.prepareStatement(sql);
                p.setString(1, nama_ekskul);
                p.executeUpdate();
                p.close();
                JOptionPane.showMessageDialog(null, "Data Terhapus");
            }catch(SQLException e){
                System.out.println("Terjadi Kesalahab");
            }finally{
                loadData();

            }
        }
        if(question == JOptionPane.CANCEL_OPTION){
        }
        btnSimpan1.setEnabled(true);
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        // TODO add your handling code here:
        btnSimpan1.setEnabled(false);
        int i = jTable3.getSelectedRow();
        if (i == -1){
            return;
        }
        
        String nama_ekskul = (String)model.getValueAt(i, 0);
        txNama.setText(nama_ekskul);
        String penanggung_jawab = (String)model.getValueAt(i, 1);
        txPenanggung.setText(penanggung_jawab);
        String lokasi = (String)model.getValueAt(i,2);
        txLokasi.setText(lokasi);
        
        /*try{
            int srow = jTable1.getSelectedRow();
            Date tanggal_lahir = (Date) new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(srow, 3));
                    txTtl.setDate(tanggal_lahir);
        }catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
                    
        }*/
        //txTtl.setDate(getTanggalFromTable(jTable1 , 3));
        //txTtl.setDate(Date.valueOf(jTable1.getValueAt(i, 3).toString()));
        
        //String alamat = (String)model.getValueAt(i, 4);
        //txAlamat.setText(alamat);
        String hari = (String)model.getValueAt(i, 3);
        cbHari.setSelectedItem(hari);
        String jam_mulai = (String)model.getValueAt(i,4);
        cbJammulai.setSelectedItem(jam_mulai);
        String jam_selesai = (String)model.getValueAt(i, 5);
        cbJamselesai.setSelectedItem(jam_selesai);
    }//GEN-LAST:event_jTable3MouseClicked

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        // TODO add your handling code here:
        clear();
        loadData();
        btnSimpan1.setEnabled(true);
        
    }//GEN-LAST:event_btnBatalActionPerformed

    private void btnBatal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatal1ActionPerformed
        // TODO add your handling code here:
        datapendaftar pp = new datapendaftar();
        pp.t = this;
        pp.setVisible(true);
        pp.setResizable(false);
    }//GEN-LAST:event_btnBatal1ActionPerformed

    private void cbJammulaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJammulaiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbJammulaiActionPerformed

    void setColor(JPanel panel){
        panel.setBackground(new Color(204,204,204));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    
    void setColor2(JPanel panel){
        panel.setBackground(new Color(102,153,255));
    }
    void resetColor2(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormDasboard3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Data_Ekstrakurikuler;
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnBatal1;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSimpan1;
    private javax.swing.JComboBox<String> cbHari;
    private javax.swing.JComboBox<String> cbJammulai;
    private javax.swing.JComboBox<String> cbJamselesai;
    private javax.swing.JPanel ha1;
    private javax.swing.JPanel ha2;
    private javax.swing.JPanel ha3;
    private javax.swing.JPanel ha4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable3;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel sidepane;
    private javax.swing.JLabel tx1;
    private javax.swing.JLabel tx2;
    private javax.swing.JLabel tx3;
    private javax.swing.JTextField txCari2;
    private javax.swing.JTextField txLokasi;
    private javax.swing.JTextField txNama;
    private javax.swing.JTextField txPenanggung;
    // End of variables declaration//GEN-END:variables
}
