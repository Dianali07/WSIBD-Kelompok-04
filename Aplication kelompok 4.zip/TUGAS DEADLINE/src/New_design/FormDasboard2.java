/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package New_design;



import Login.Koneksi;
import Login.Login;
import groovyjarjarcommonscli.ParseException;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ADAM
 */
public class FormDasboard2 extends javax.swing.JFrame {
    int dragxmouse;
    int dragymouse;
    Koneksi koneksi = new Koneksi();
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private DefaultTableModel model3;

    String IDnya = "";
    String selectedItemStrNama;
    
    public String txId,namasiswa,nis_siswa;
    public void pelanggan_pen() {
        
        try {
                Connection c = Koneksi.getKoneksi();
                Statement s = c.createStatement();
                String sql = "SELECT * FROM yu.siswa";
                
                ResultSet r = s.executeQuery(sql);
                
                    while(r.next()) {
                       // cbNis.addItem((r.getString(2)));
                        IDnya = r.getString(1);
                        
                        
                    }
                    
                    
                    r.close();
                    s.close();
                        } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, ex, ex.getMessage(), WIDTH, null);
                        }
    }
    
    /*public void tampil_combo_siswa(){
     try{
          Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM `user` ORDER BY `id_siswa` ASC";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                //cbNis.addItem(r.getString(""));
                
            }
            r.last();
            int jumalahdata = r.getRow();
            r.first();
     }catch(Exception e){
         
     }*/
     
    public void itemTerpilih() {
        popupdasboard2 pp = new popupdasboard2();
        pp.brg = this;
        txNis1.setText(txId);
        txNamaPendaftar.setText(namasiswa);
        
    }
         
    //}
     
      public void loadData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT nis,username,password FROM user INNER JOIN siswa ON user."
                    + "id_siswa= siswa.id_siswa ";
            ResultSet r = s.executeQuery(sql);
            
            
            while(r.next()){
                Object[] o = new Object[3];
                o [0] = r.getString("nis");
                o [1] = r.getString("username");
                o [2] = r.getString("password");
                
                
                
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        FormDasboard f2 = new FormDasboard();
        
        setVisible(true);
        jTable2.setModel(model);
        
        int  c = model.getRowCount();
        
        f2.txId3.setText(""+c);
        setVisible(true);

      }
    
     
    
    //public static Date getTanggalFromTable(JTable table, int kolom)
    {
      /*  JTable tabel = table;
        String str_tgl = String.valueOf(tabel.getValueAt(tabel.getSelectedRow(), kolom));
        Date tanggal = null;
        try {
            tanggal =  new SimpleDateFormat("yyyy-MM-dd").parse(str_tgl);
            
        } catch (java.text.ParseException ex) {
            Logger.getLogger(FormDasboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tanggal;
    }   
     */
        
    }    
     public void clear(){
         
        txUsername.setText("");
        txPassword.setText("");
        txConPassword.setText("");
        txConPassword.setText("");
        txNamaPendaftar.setText("");
        
        
    }       
    /**
     * Creates new form DataPendaftaran
     */
    public FormDasboard2() {
        initComponents();
        this.setLocationRelativeTo(null);
        pelanggan_pen();
        txNamaPendaftar.setEnabled(false);
        txNis1.setEnabled(false);
        //tampil_combo_siswa();
        itemTerpilih();
        model = new DefaultTableModel();
        
        jTable2.setModel(model);
        
        model.addColumn("nis");
        model.addColumn("username");
        model.addColumn("password");
        
        
        loadData();
        
       
    }
     public Connection conn;
     
    
       
    private void autonumber(){
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            String sql = "SELECT * FROM nama_terdaftar ORDER BY id DESC";
            ResultSet r = s.executeQuery(sql);
            if (r.next()){
                String NoDaftar = r.getString("id").substring(2);
                String DR = "" + (Integer.parseInt(NoDaftar) + 1);  
                String Nol = "";
                
                if(DR.length()==1){
                    Nol = "00";
                }else if(DR.length()==2){
                    Nol = "0";
                }else if(DR.length()==3){
                    Nol = "";
                }
                
                //txId.setText("BR" + Nol + DR);
                
            }else{
               // txId.setText("DR001");
            }
            r.close();
            s.close();
        }catch(Exception e){
            System.out.println("autonumber error");
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        sidepane = new javax.swing.JPanel();
        ha1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ha2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ha3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        ha4 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        Data_Pengguna = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txConPassword = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        txCari1 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        txUsername = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        txPassword = new javax.swing.JTextField();
        jLabel41 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox<>();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        btnSimpan1 = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnBatal = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        txNamaPendaftar = new javax.swing.JTextField();
        txNis1 = new javax.swing.JTextField();
        jLabel47 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidepane.setBackground(new java.awt.Color(51, 51, 51));
        sidepane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ha1.setBackground(new java.awt.Color(60, 60, 60));
        ha1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha1MousePressed(evt);
            }
        });
        ha1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-home-15 (1).png"))); // NOI18N
        ha1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 0, 34, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Dashboard");
        ha1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, 74, 24));

        sidepane.add(ha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 260, 50));

        ha2.setBackground(new java.awt.Color(60, 60, 60));
        ha2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha2MousePressed(evt);
            }
        });
        ha2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-group-15.png"))); // NOI18N
        ha2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Data Siswa");
        ha2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 260, 60));

        ha3.setBackground(new java.awt.Color(60, 60, 60));
        ha3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha3MousePressed(evt);
            }
        });
        ha3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-user-male-15.png"))); // NOI18N
        ha3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Data Pengguna");
        ha3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 260, 60));

        ha4.setBackground(new java.awt.Color(60, 60, 60));
        ha4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha4MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha4MousePressed(evt);
            }
        });
        ha4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-price-tag-15.png"))); // NOI18N
        ha4.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 20, 60));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Data Ekstrakurikuler");
        ha4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 260, 60));
        sidepane.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 220, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/2-removebg-preview.png"))); // NOI18N
        sidepane.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SMAN 1 PESANGGARAN");
        sidepane.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 170, 28));

        bg.add(sidepane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 656));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-xbox-x-30.png"))); // NOI18N
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        bg.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 20, -1, -1));

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setLayout(new java.awt.CardLayout());

        Data_Pengguna.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setPreferredSize(new java.awt.Dimension(716, 438));

        jLabel39.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel39.setText("Konfirmasi Password");

        txCari1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txCari1ActionPerformed(evt);
            }
        });
        txCari1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txCari1KeyTyped(evt);
            }
        });

        jLabel22.setText("Cari Data");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setText("Kelola Pengguna");

        jLabel21.setText("Admin/Kelola Pengguna");

        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel44.setText("Id");

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel45.setText("Username");

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel46.setText("Password");

        jLabel41.setText("Status");

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1" }));
        cbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbStatusActionPerformed(evt);
            }
        });

        jLabel42.setText("admin = 1");

        jLabel43.setText("user = 0");

        btnSimpan1.setText("Simpan");
        btnSimpan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpan1ActionPerformed(evt);
            }
        });

        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });

        jButton1.setText("cari");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel47.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel47.setText("Nama Pendaftar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel20)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnSimpan1))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel22)
                            .addGap(18, 18, 18)
                            .addComponent(txCari1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jLabel45)
                                                        .addComponent(jLabel44))
                                                    .addGap(115, 115, 115))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(txNis1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addGap(18, 18, 18)))
                                            .addComponent(jButton1)
                                            .addGap(56, 56, 56)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(1, 1, 1)
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jLabel46)
                                                            .addComponent(txPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                    .addComponent(jLabel39))
                                                .addComponent(txConPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGap(75, 75, 75))
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(btnBatal)
                                            .addGap(35, 35, 35)
                                            .addComponent(btnDelete)
                                            .addGap(213, 213, 213)))
                                    .addComponent(jLabel41)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel43)
                                        .addComponent(jLabel42)))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel21)
                                    .addGap(363, 363, 363)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel47)
                                        .addComponent(txNamaPendaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(125, 125, 125)
                            .addComponent(jLabel45))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel47)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txNamaPendaftar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel41))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel42)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel43)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel44)
                            .addComponent(jLabel46))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1)
                            .addComponent(txNis1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel39)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txUsername, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txConPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnSimpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txCari1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22)
                            .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnBatal, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout Data_PenggunaLayout = new javax.swing.GroupLayout(Data_Pengguna);
        Data_Pengguna.setLayout(Data_PenggunaLayout);
        Data_PenggunaLayout.setHorizontalGroup(
            Data_PenggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PenggunaLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        Data_PenggunaLayout.setVerticalGroup(
            Data_PenggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PenggunaLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(152, Short.MAX_VALUE))
        );

        mainPanel.add(Data_Pengguna, "card4");

        bg.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 780, 590));

        jLabel11.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel11MouseDragged(evt);
            }
        });
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel11MousePressed(evt);
            }
        });
        bg.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1035, 656));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
       this.dispose();
       ClassLogin a = new ClassLogin();
       a.setVisible(true);
    }//GEN-LAST:event_jLabel8MouseClicked

    private void ha2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MousePressed
        // TODO add your handling code here:
        //setColor(ha2);
        //resetColor(ha1);
    }//GEN-LAST:event_ha2MousePressed

    private void ha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MousePressed
        // TODO add your handling code here:
        
       // setColor(ha1);
        //resetColor(ha2);
        
    }//GEN-LAST:event_ha1MousePressed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel11MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MousePressed
        // TODO add your handling code here:
            dragxmouse = evt.getX();
            dragymouse = evt.getY();
    }//GEN-LAST:event_jLabel11MousePressed

    private void jLabel11MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseDragged
        // TODO add your handling code here:
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
         
         this.setLocation(x - dragxmouse,y- dragymouse );
         System.out.println(x+""+y);
         
    }//GEN-LAST:event_jLabel11MouseDragged

    private void ha1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseEntered
        // TODO add your handling code here:
        setColor(ha1);
        
    }//GEN-LAST:event_ha1MouseEntered

    private void ha1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseExited
        // TODO add your handling code here:
        resetColor(ha1);
        
    }//GEN-LAST:event_ha1MouseExited

    private void ha2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseEntered
        setColor(ha2);
    }//GEN-LAST:event_ha2MouseEntered

    private void ha2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseExited
        resetColor(ha2);
    }//GEN-LAST:event_ha2MouseExited

    private void ha1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseClicked
        // TODO add your handling code here:
        setColor2(ha1);
        resetColor2(ha2);
        //remove panel
       this.dispose();
        FormDasboard a = new FormDasboard();
        a.setVisible(true);
       
        resetColor2(ha2);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha1MouseClicked

    private void ha2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseClicked
        // TODO add your handling code here:
         //remove panel

        
        //addpanel
       this.dispose();
        FormDasboard1 a = new FormDasboard1();
        a.setVisible(true);
        setColor2(ha2);
        resetColor2(ha1);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha2MouseClicked

    private void ha3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseClicked
        // TODO add your handling code here:
        
        
        //addpanel
       
        setColor2(ha3);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha4);
    }//GEN-LAST:event_ha3MouseClicked

    private void ha3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseEntered
        // TODO add your handling code here:
        setColor(ha3);
    }//GEN-LAST:event_ha3MouseEntered

    private void ha3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseExited
        // TODO add your handling code here:
        resetColor(ha3);
    }//GEN-LAST:event_ha3MouseExited

    private void ha3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MousePressed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_ha3MousePressed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        btnSimpan1.setEnabled(false);
        int i = jTable2.getSelectedRow();
        if (i == -1){
            return;
        }
        String nis = (String)model.getValueAt(i, 0);
        txNamaPendaftar.setText(nis);
        String username = (String)model.getValueAt(i, 1);
        txUsername.setText(username);
        String password = (String)model.getValueAt(i, 2);
        txPassword.setText(password);
        
        
        
    }//GEN-LAST:event_jTable2MouseClicked

    private void txCari1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txCari1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txCari1ActionPerformed

    private void txCari1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txCari1KeyTyped
       
        DefaultTableModel tabel = new DefaultTableModel();
        
        tabel.addColumn("nis");
        tabel.addColumn("username");
        tabel.addColumn("password");
        
        
        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "SELECT nis,username,password FROM user INNER JOIN siswa ON user.id_siswa= siswa.id_siswa where username like '%" + txCari1.getText() + "%'";
            Statement stat = c.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while(rs.next()){
                tabel.addRow(new Object[]{
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    
                });
            }
            jTable2.setModel(tabel);
            
        }catch(Exception e){
           System.out.println("Cari Data Error");
        }finally{
        }
        
    }//GEN-LAST:event_txCari1KeyTyped

    private void ha4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseClicked
        
        
        //addpanel
        this.dispose();
        FormDasboard3 a = new FormDasboard3();
        a.setVisible(true);
        setColor2(ha4);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha3);
        
    }//GEN-LAST:event_ha4MouseClicked

    private void ha4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseEntered
        // TODO add your handling code here:
        setColor(ha4);
    }//GEN-LAST:event_ha4MouseEntered

    private void ha4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseExited
        // TODO add your handling code here:
        resetColor(ha4);
    }//GEN-LAST:event_ha4MouseExited

    private void ha4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_ha4MousePressed

    private void btnSimpan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpan1ActionPerformed
        // TODO add your handling code here:
        String id_user = null;
        String nis = txNamaPendaftar.getText().toString().trim();
        String username = txUsername.getText().toString().trim();
        String password = txPassword.getText().toString().trim();
        String conPassword = txConPassword.getText().toString().trim();
        String role = (String) cbStatus.getSelectedItem();
        
        if(!password.equals(conPassword)){
            JOptionPane.showMessageDialog(null, "Password not match");
        }else if(password.equals("") || username.equals("")){
            JOptionPane.showMessageDialog(null, "Username or Password cannot be empty");
            
        }else{
            try{
            Connection c = Koneksi.getKoneksi();
            String sql ="INSERT INTO user VALUES (?,?,?,?,?)";
            PreparedStatement p = c.prepareStatement(sql);
            p.setString(1, id_user);
            p.setString(2, username);
            p.setString(3, password);
            p.setString(4, role);
            p.setString(5, IDnya);
            p.executeUpdate();
            p.close();
            JOptionPane.showMessageDialog(null, "Create Account Successfully");
            
            
        }catch(SQLException e){
                System.out.println("Error");
        }finally{
            clear();
            loadData();
        }
        }
    }//GEN-LAST:event_btnSimpan1ActionPerformed

    private void cbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbStatusActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        // TODO add your handling code here:
        int i = jTable2.getSelectedRow();
        if(i == -1){
            return;
        }
        
        String username = (String)model.getValueAt(i, 1);
        txUsername.setText(username);
        
        int question = JOptionPane.showConfirmDialog(null, "Yakin Data Akan Dihapus?","Konfirmasi", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE);
        if(question == JOptionPane.OK_OPTION){
            try{
                Connection c = Koneksi.getKoneksi();
                String sql = "DELETE FROM user WHERE username = ?";
                PreparedStatement p = c.prepareStatement(sql);
                p.setString(1, username);
                p.executeUpdate();
                p.close();
                JOptionPane.showMessageDialog(null, "Data Terhapus");
            }catch(SQLException e){
                System.out.println("Terjadi Kesalahab");
            }finally{
                loadData();
                clear();
                btnSimpan1.setEnabled(true);
            }
        }
        if(question == JOptionPane.CANCEL_OPTION){
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
        // TODO add your handling code here:
        clear();
        loadData();
        btnSimpan1.setEnabled(true);
        
    }//GEN-LAST:event_btnBatalActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        popupdasboard2 pp = new popupdasboard2();
        pp.brg = this;
        pp.setVisible(true);
        pp.setResizable(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    void setColor(JPanel panel){
        panel.setBackground(new Color(204,204,204));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    
    void setColor2(JPanel panel){
        panel.setBackground(new Color(102,153,255));
    }
    void resetColor2(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormDasboard2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Data_Pengguna;
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnSimpan1;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JPanel ha1;
    private javax.swing.JPanel ha2;
    private javax.swing.JPanel ha3;
    private javax.swing.JPanel ha4;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable2;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel sidepane;
    private javax.swing.JTextField txCari1;
    private javax.swing.JTextField txConPassword;
    public javax.swing.JTextField txNamaPendaftar;
    public javax.swing.JTextField txNis1;
    private javax.swing.JTextField txPassword;
    private javax.swing.JTextField txUsername;
    // End of variables declaration//GEN-END:variables
}
