/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package New_design.gambar;



import New_design.*;
import Login.Koneksi;
import Login.Login;
import groovyjarjarcommonscli.ParseException;
import java.awt.Color;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
/**
 *
 * @author ADAM
 */
public class FormDasboard extends javax.swing.JFrame {
    int dragxmouse;
    int dragymouse;
    Koneksi koneksi = new Koneksi();
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private DefaultTableModel model3;

    
    
    
    public void tampil_combo_siswa(){
     try{
          Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM user INNER JOIN siswa ON user.id_siswa = siswa.id_siswa ";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                cbNis.addItem(r.getString("nis"));
                
            }
            r.last();
            int jumalahdata = r.getRow();
            r.first();
     }catch(Exception e){
         
     }
     

         
    }
     
      public void loadData(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT nis,username,password FROM user INNER JOIN siswa ON user."
                    + "id_siswa= siswa.id_siswa ";
            ResultSet r = s.executeQuery(sql);
            
            
            while(r.next()){
                Object[] o = new Object[3];
                o [0] = r.getString("nis");
                o [1] = r.getString("username");
                o [2] = r.getString("password");
                
                
                
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        int  f = model.getRowCount();
        txId3.setText(""+f);
        int  s = model.getRowCount();
        //txId.setText(""+s);
        setVisible(true);
        jTable2.setModel(model);
        
        int  c = model.getRowCount();
        c = c + 1;
        txId.setText(""+c);
        setVisible(true);

      }
    
     
      public void loadData2(){
         model.getDataVector().removeAllElements();
         model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM siswa";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[8];
                o [0] = r.getString("nis");
                o [1] = r.getString("nama_siswa");
                o [2] = r.getString("tempat_lahir");
                o [3] = r.getString("tanggal_lahir");
                o [4] = r.getString("alamat");
                o [5] = r.getString("kelas");
                o [6] = r.getString("jurusan");
                o [7] = r.getString("rombel");
               
                
                
                
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        int  b = model.getRowCount();
        b = b + 1;
        txId_siswa2.setText(""+b);
        setVisible(true);
        
        
        int  g = model.getRowCount();
        txId2.setText(""+g);
        
        setVisible(true);
        
        jTable1.setModel(model);
    }    
      
    public void loadData3(){
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            
            String sql = "SELECT * FROM ekskul";
            ResultSet r = s.executeQuery(sql);
            
            while(r.next()){
                Object[] o = new Object[6];
                
                o [0] = r.getString("nama_ekskul");
                o [1] = r.getString("penanggung_jawab");
                o [2] = r.getString("lokasi");
                o [3] = r.getString("hari");
                o [4] = r.getString("jam_mulai");
                o [5] = r.getString("jam_selesai");
               
                
            
                model.addRow(o);
                
            }
            r.close();
            s.close();
        }catch(SQLException e){
            System.out.println("terjadi kesalahan");
        }
        int  c = model.getRowCount();
        txId1.setText(""+c);
        setVisible(true);
        jTable3.setModel(model);
    } 
    
    //public static Date getTanggalFromTable(JTable table, int kolom)
    {
      /*  JTable tabel = table;
        String str_tgl = String.valueOf(tabel.getValueAt(tabel.getSelectedRow(), kolom));
        Date tanggal = null;
        try {
            tanggal =  new SimpleDateFormat("yyyy-MM-dd").parse(str_tgl);
            
        } catch (java.text.ParseException ex) {
            Logger.getLogger(FormDasboard.class.getName()).log(Level.SEVERE, null, ex);
        }
        return tanggal;
    }   
     */
        
    }    
     public void clearSiswa(){
         
        txNis.setText("");
        txNama.setText("");
        txTl.setText("");
        txAlamat.setText("");
        txKelas.setSelectedIndex(0);
        txJurusan.setSelectedIndex(0);
        txGolongan.setSelectedIndex(0);
        
    }       
    /**
     * Creates new form DataPendaftaran
     */
    public FormDasboard() {
        initComponents();
        this.setLocationRelativeTo(null);
        //txId.setEnabled(false);
        tampil_combo_siswa();
       
        model = new DefaultTableModel();
        
        jTable2.setModel(model);
        
        model.addColumn("nis");
        model.addColumn("username");
        model.addColumn("password");
        
        
        loadData();
        
        
        
        model = new DefaultTableModel();
        
        jTable1.setModel(model);
        
        
        model.addColumn("Nis");
        model.addColumn("Nama");
        model.addColumn("Tempat lahir");
        model.addColumn("Tanggal lahir");
        model.addColumn("Alamat");
        model.addColumn("Kelas");
        model.addColumn("Jurusan");
        model.addColumn("Golongan");
        
        
        loadData2();
        
        model = new DefaultTableModel();
        
        jTable3.setModel(model);
        
        
        model.addColumn("Nama Ekstrakurikuler");
        model.addColumn("Penanggung jawab");
        model.addColumn("Lokasi Ekskul");
        model.addColumn("Hari");
        model.addColumn("Jam Mulai");
        model.addColumn("Jam Selesai");
        
        loadData3();
        
       
    }
     public Connection conn;
     
    
       
    private void autonumber(){
        try{
            Connection c = Koneksi.getKoneksi();
            Statement s = c.createStatement();
            String sql = "SELECT * FROM nama_terdaftar ORDER BY id DESC";
            ResultSet r = s.executeQuery(sql);
            if (r.next()){
                String NoDaftar = r.getString("id").substring(2);
                String DR = "" + (Integer.parseInt(NoDaftar) + 1);  
                String Nol = "";
                
                if(DR.length()==1){
                    Nol = "00";
                }else if(DR.length()==2){
                    Nol = "0";
                }else if(DR.length()==3){
                    Nol = "";
                }
                
                //txId.setText("BR" + Nol + DR);
                
            }else{
               // txId.setText("DR001");
            }
            r.close();
            s.close();
        }catch(Exception e){
            System.out.println("autonumber error");
        }
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        sidepane = new javax.swing.JPanel();
        ha1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        ha2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ha3 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        ha4 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        mainPanel = new javax.swing.JPanel();
        Dashboard = new javax.swing.JPanel();
        dashboard = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txId1 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        txId2 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        txId3 = new javax.swing.JLabel();
        Data_Siswa = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        txCari = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txNis = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        txNama = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        txTl = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txAlamat = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        txKelas = new javax.swing.JComboBox<>();
        jLabel49 = new javax.swing.JLabel();
        txJurusan = new javax.swing.JComboBox<>();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        txGolongan = new javax.swing.JComboBox<>();
        btnSimpan = new javax.swing.JButton();
        txId_siswa2 = new javax.swing.JTextField();
        txTtl = new javax.swing.JTextField();
        Data_Pengguna = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txCari1 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        Input_data_pengguna = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txUsername = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        txPassword = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        txConPassword = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        btnSimpan1 = new javax.swing.JButton();
        cbNis = new javax.swing.JComboBox<>();
        cbStatus = new javax.swing.JComboBox<>();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        txId = new javax.swing.JTextField();
        Data_Ekstrakurikuler = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        txCari2 = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setUndecorated(true);

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        sidepane.setBackground(new java.awt.Color(51, 51, 51));
        sidepane.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ha1.setBackground(new java.awt.Color(60, 60, 60));
        ha1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha1MousePressed(evt);
            }
        });
        ha1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-home-15 (1).png"))); // NOI18N
        ha1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 0, 34, 50));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Dashboard");
        ha1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, 74, 24));

        sidepane.add(ha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 260, 50));

        ha2.setBackground(new java.awt.Color(60, 60, 60));
        ha2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha2MousePressed(evt);
            }
        });
        ha2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-group-15.png"))); // NOI18N
        ha2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Data Siswa");
        ha2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 260, 60));

        ha3.setBackground(new java.awt.Color(60, 60, 60));
        ha3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha3MousePressed(evt);
            }
        });
        ha3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-user-male-15.png"))); // NOI18N
        ha3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 60));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Data Pengguna");
        ha3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 220, 260, 60));

        ha4.setBackground(new java.awt.Color(60, 60, 60));
        ha4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ha4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ha4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ha4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ha4MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ha4MousePressed(evt);
            }
        });
        ha4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-price-tag-15.png"))); // NOI18N
        ha4.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 20, 60));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Data Ekstrakurikuler");
        ha4.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(53, 13, -1, 34));

        sidepane.add(ha4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 260, 60));
        sidepane.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 220, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/2-removebg-preview.png"))); // NOI18N
        sidepane.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SMAN 1 PESANGGARAN");
        sidepane.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 30, 170, 28));

        bg.add(sidepane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 656));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-xbox-x-30.png"))); // NOI18N
        jLabel8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        bg.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 20, -1, -1));

        mainPanel.setBackground(new java.awt.Color(255, 255, 255));
        mainPanel.setLayout(new java.awt.CardLayout());

        Dashboard.setBackground(new java.awt.Color(255, 255, 255));
        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dashboard.setBackground(new java.awt.Color(204, 204, 204));
        dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Total Akun");
        dashboard.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 90, -1, -1));

        jLabel6.setForeground(new java.awt.Color(102, 102, 102));
        jLabel6.setText("Selamat Datang Administrator");
        dashboard.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 55, -1, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setText("Dashboard");
        dashboard.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(26, 24, -1, -1));

        txId1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        txId1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txId1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dashboard.add(txId1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 120, 90, 94));

        jLabel33.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel33.setText("Total Ekskul");
        dashboard.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 90, -1, -1));

        txId2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        txId2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txId2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dashboard.add(txId2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 120, 100, 94));

        jLabel34.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel34.setText("Total Siswa");
        dashboard.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, -1, -1));

        txId3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        txId3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txId3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dashboard.add(txId3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 90, 94));

        Dashboard.add(dashboard, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 740, 240));

        mainPanel.add(Dashboard, "card2");

        Data_Siswa.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        txCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txCariActionPerformed(evt);
            }
        });
        txCari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txCariKeyTyped(evt);
            }
        });

        jLabel15.setText("Cari Nama");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel23.setText("Kelola Siswa");

        jLabel12.setText("Admin / Data Siswa");

        jLabel44.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel44.setText("NIS");

        txNama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txNamaActionPerformed(evt);
            }
        });

        jLabel45.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel45.setText("Nama Siswa");

        jLabel46.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel46.setText("Tempat Lahir");

        jLabel47.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel47.setText("Tanggal Lahir  (yyyy-MM-dd)");

        jLabel48.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel48.setText("Alamat");

        txKelas.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "10", "11", "12" }));

        jLabel49.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel49.setText("Kelas");

        txJurusan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "IPA", "IPS" }));

        jLabel50.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel50.setText("Jurusan");

        jLabel51.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel51.setText("Golongan");

        txGolongan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih", "1", "2", "3", "4", "5", "6", " " }));

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });

        txId_siswa2.setBackground(new java.awt.Color(240, 240, 240));
        txId_siswa2.setBorder(null);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnSimpan)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel46)
                                    .addComponent(jLabel44)
                                    .addComponent(txNis)
                                    .addComponent(jLabel45)
                                    .addComponent(txNama)
                                    .addComponent(txTl)
                                    .addComponent(txTtl))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel48)
                            .addComponent(jLabel49)
                            .addComponent(txAlamat)
                            .addComponent(txKelas, 0, 210, Short.MAX_VALUE)
                            .addComponent(jLabel50)
                            .addComponent(txJurusan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel51)
                            .addComponent(txGolongan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txCari, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15))
                        .addGap(28, 28, 28))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 669, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel23)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txId_siswa2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txId_siswa2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel44)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txNis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel45)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel46)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txTl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel48)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel49)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txKelas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel50)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txJurusan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel47)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txTtl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel51)
                            .addComponent(jLabel15))
                        .addGap(8, 8, 8)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txGolongan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSimpan, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout Data_SiswaLayout = new javax.swing.GroupLayout(Data_Siswa);
        Data_Siswa.setLayout(Data_SiswaLayout);
        Data_SiswaLayout.setHorizontalGroup(
            Data_SiswaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_SiswaLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );
        Data_SiswaLayout.setVerticalGroup(
            Data_SiswaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_SiswaLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 15, Short.MAX_VALUE))
        );

        mainPanel.add(Data_Siswa, "card3");

        Data_Pengguna.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setPreferredSize(new java.awt.Dimension(716, 438));

        txCari1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txCari1ActionPerformed(evt);
            }
        });
        txCari1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txCari1KeyTyped(evt);
            }
        });

        jLabel22.setText("Cari Data");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setText("Kelola Pengguna");

        jLabel21.setText("Admin/Kelola Pengguna");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel21)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel22)
                            .addGap(18, 18, 18)
                            .addComponent(txCari1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel20)
                            .addGap(513, 513, 513))))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txCari1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton2.setText("+");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Data_PenggunaLayout = new javax.swing.GroupLayout(Data_Pengguna);
        Data_Pengguna.setLayout(Data_PenggunaLayout);
        Data_PenggunaLayout.setHorizontalGroup(
            Data_PenggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PenggunaLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Data_PenggunaLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(41, 41, 41))
        );
        Data_PenggunaLayout.setVerticalGroup(
            Data_PenggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_PenggunaLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        mainPanel.add(Data_Pengguna, "card4");

        Input_data_pengguna.setBackground(new java.awt.Color(255, 255, 255));

        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel36.setText("NIS");

        jLabel37.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel37.setText("Username");

        jLabel38.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel38.setText("Password");

        jLabel39.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel39.setText("Konfirmasi Password");

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/New_design/gambar/icons8-xbox-x-20.png"))); // NOI18N
        jLabel40.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel40.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel40MouseClicked(evt);
            }
        });

        btnSimpan1.setText("Simpan");
        btnSimpan1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpan1ActionPerformed(evt);
            }
        });

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "0", "1", " " }));
        cbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbStatusActionPerformed(evt);
            }
        });

        jLabel41.setText("Status");

        jLabel42.setText("admin = 1");

        jLabel43.setText("user = 0");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbNis, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSimpan1)
                    .addComponent(jLabel39)
                    .addComponent(txConPassword, javax.swing.GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
                    .addComponent(jLabel38)
                    .addComponent(txPassword, javax.swing.GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
                    .addComponent(jLabel37)
                    .addComponent(txUsername, javax.swing.GroupLayout.DEFAULT_SIZE, 406, Short.MAX_VALUE)
                    .addComponent(jLabel36))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addComponent(jLabel41)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel43))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel42))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(jLabel40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(txId, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel40)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel36)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cbNis, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel37)
                                .addGap(18, 18, 18)
                                .addComponent(txUsername, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel38)
                                .addGap(18, 18, 18)
                                .addComponent(txPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel39)
                                .addGap(31, 31, 31)
                                .addComponent(txConPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnSimpan1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel41))
                                .addContainerGap(28, Short.MAX_VALUE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel42)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel43)
                                .addGap(21, 21, 21))))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(txId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout Input_data_penggunaLayout = new javax.swing.GroupLayout(Input_data_pengguna);
        Input_data_pengguna.setLayout(Input_data_penggunaLayout);
        Input_data_penggunaLayout.setHorizontalGroup(
            Input_data_penggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Input_data_penggunaLayout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );
        Input_data_penggunaLayout.setVerticalGroup(
            Input_data_penggunaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Input_data_penggunaLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(85, Short.MAX_VALUE))
        );

        mainPanel.add(Input_data_pengguna, "card7");

        Data_Ekstrakurikuler.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setPreferredSize(new java.awt.Dimension(716, 438));

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel26.setText("Kelola Ekskul");

        jLabel27.setText("Admin / Data Ekstrakurikuler");

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        txCari2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txCari2ActionPerformed(evt);
            }
        });
        txCari2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txCari2KeyTyped(evt);
            }
        });

        jLabel35.setText("Cari Data");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txCari2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel27)
                        .addComponent(jLabel26)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 663, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35)
                    .addComponent(txCari2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50))
        );

        javax.swing.GroupLayout Data_EkstrakurikulerLayout = new javax.swing.GroupLayout(Data_Ekstrakurikuler);
        Data_Ekstrakurikuler.setLayout(Data_EkstrakurikulerLayout);
        Data_EkstrakurikulerLayout.setHorizontalGroup(
            Data_EkstrakurikulerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_EkstrakurikulerLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(37, Short.MAX_VALUE))
        );
        Data_EkstrakurikulerLayout.setVerticalGroup(
            Data_EkstrakurikulerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Data_EkstrakurikulerLayout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 152, Short.MAX_VALUE))
        );

        mainPanel.add(Data_Ekstrakurikuler, "card5");

        bg.add(mainPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 70, 780, 590));

        jLabel11.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel11MouseDragged(evt);
            }
        });
        jLabel11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel11MouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel11MousePressed(evt);
            }
        });
        bg.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 660));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        setSize(new java.awt.Dimension(1035, 656));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
       this.dispose();
    }//GEN-LAST:event_jLabel8MouseClicked

    private void ha2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MousePressed
        // TODO add your handling code here:
        //setColor(ha2);
        //resetColor(ha1);
    }//GEN-LAST:event_ha2MousePressed

    private void ha1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MousePressed
        // TODO add your handling code here:
        
       // setColor(ha1);
        //resetColor(ha2);
        
    }//GEN-LAST:event_ha1MousePressed

    private void jLabel11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel11MouseClicked

    private void jLabel11MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MousePressed
        // TODO add your handling code here:
            dragxmouse = evt.getX();
            dragymouse = evt.getY();
    }//GEN-LAST:event_jLabel11MousePressed

    private void jLabel11MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel11MouseDragged
        // TODO add your handling code here:
          int x = evt.getXOnScreen();
          int y = evt.getYOnScreen();
         
         this.setLocation(x - dragxmouse,y- dragymouse );
         System.out.println(x+""+y);
         
    }//GEN-LAST:event_jLabel11MouseDragged

    private void ha1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseEntered
        // TODO add your handling code here:
        setColor(ha1);
        
    }//GEN-LAST:event_ha1MouseEntered

    private void ha1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseExited
        // TODO add your handling code here:
        resetColor(ha1);
        
    }//GEN-LAST:event_ha1MouseExited

    private void ha2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseEntered
        setColor(ha2);
    }//GEN-LAST:event_ha2MouseEntered

    private void ha2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseExited
        resetColor(ha2);
    }//GEN-LAST:event_ha2MouseExited

    private void ha1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha1MouseClicked
        // TODO add your handling code here:
        setColor2(ha1);
        resetColor2(ha2);
        //remove panel
       
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();
        
        //addpanel
        mainPanel.add(Dashboard);
        mainPanel.repaint();
        mainPanel.revalidate();
        setColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha1MouseClicked

    private void ha2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha2MouseClicked
        // TODO add your handling code here:
         //remove panel
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();
        
        //addpanel
        mainPanel.add(Data_Siswa);
        mainPanel.repaint();
        mainPanel.revalidate();
        setColor2(ha2);
        resetColor2(ha1);
        resetColor2(ha3);
        resetColor2(ha4);
    }//GEN-LAST:event_ha2MouseClicked

    private void ha3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseClicked
        // TODO add your handling code here:
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();
        
        //addpanel
        mainPanel.add(Data_Pengguna);
        mainPanel.repaint();
        mainPanel.revalidate();
        setColor2(ha3);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha4);
    }//GEN-LAST:event_ha3MouseClicked

    private void ha3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseEntered
        // TODO add your handling code here:
        setColor(ha3);
    }//GEN-LAST:event_ha3MouseEntered

    private void ha3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MouseExited
        // TODO add your handling code here:
        resetColor(ha3);
    }//GEN-LAST:event_ha3MouseExited

    private void ha3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha3MousePressed
        // TODO add your handling code here:
      
    }//GEN-LAST:event_ha3MousePressed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
    
        
    }//GEN-LAST:event_jTable2MouseClicked

    private void txCari1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txCari1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txCari1ActionPerformed

    private void txCari1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txCari1KeyTyped
       
        DefaultTableModel tabel = new DefaultTableModel();
        
        tabel.addColumn("nis");
        tabel.addColumn("username");
        tabel.addColumn("password");
        
        
        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "SELECT nis,username,password FROM user INNER JOIN siswa ON user.id_siswa= siswa.id_siswa where username like '%" + txCari1.getText() + "%'";
            Statement stat = c.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while(rs.next()){
                tabel.addRow(new Object[]{
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    
                });
            }
            jTable2.setModel(tabel);
            
        }catch(Exception e){
           System.out.println("Cari Data Error");
        }finally{
        }
        
    }//GEN-LAST:event_txCari1KeyTyped

    private void txCariKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txCariKeyTyped
            // TODO add your handling code here:
        DefaultTableModel tabel = new DefaultTableModel();

        tabel.addColumn("Nis");
        tabel.addColumn("Nama");
        tabel.addColumn("Tempat lahir");
        tabel.addColumn("Tanggal lahir");
        tabel.addColumn("Alamat");
        tabel.addColumn("Kelas");
        tabel.addColumn("Jurusan");
        tabel.addColumn("Golongan");

        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "Select nis,nama_siswa,tempat_lahir,tanggal_lahir,alamat,kelas,jurusan,rombel from siswa where nama_siswa like '%" + txCari.getText() + "%'";
            Statement stat = c.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while(rs.next()){
                tabel.addRow(new Object[]{
                    rs.getString(1),
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    rs.getString(8),
                });
            }
            jTable1.setModel(tabel);
            
        }catch(Exception e){
            System.out.println("Cari Data Error");
        }finally{
        }
    }//GEN-LAST:event_txCariKeyTyped

    private void txCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txCariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txCariActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        
        /*int bar = jTable1.getSelectedRow();
        
        String a = model.getValueAt(bar, 0).toString();
        String b = model.getValueAt(bar, 1).toString();
        String c = model.getValueAt(bar, 2).toString();
        String d = model.getValueAt(bar, 3).toString();
        String e = model.getValueAt(bar, 4).toString();
        String f = model.getValueAt(bar, 5).toString();
        String g = model.getValueAt(bar, 6).toString();
        String h = model.getValueAt(bar, 7).toString();
        String i = model.getValueAt(bar, 8).toString();

        
        
        txTtl.setText(d);
        txId_siswa2.setText(a);
        txNis.setText(b);
        txNama.setText(c);
        txTl.setText(e);
        txAlamat.setText(f);
        txKelas.setSelectedItem(g);
        txJurusan.setSelectedItem(h);
        txGolongan.setSelectedItem(i);*/
       
        
        
        
           btnSimpan.setEnabled(false);
        int i = jTable1.getSelectedRow();
        if (i == -1){
            return;
        }
        String id_siswa = (String)model.getValueAt(i, 0);
        txId_siswa2.setText(id_siswa);
        String nis = (String)model.getValueAt(i, 1);
        txNis.setText(nis);
        String nama_siswa = (String)model.getValueAt(i, 1);
        txNama.setText(nama_siswa);
        String tempat_lahir = (String)model.getValueAt(i,2);
        txTl.setText(tempat_lahir);
        
        String tanggal_lahir = (String)model.getValueAt(i, 3);
        txTtl.setText(tanggal_lahir);
        
        String alamat = (String)model.getValueAt(i, 4);
        txAlamat.setText(alamat);
        String kelas = (String)model.getValueAt(i, 5);
        txKelas.setSelectedItem(kelas);
        String jurusan = (String)model.getValueAt(i,6);
        txJurusan.setSelectedItem(jurusan);
        String rombel = (String)model.getValueAt(i, 7);
        txGolongan.setSelectedItem(rombel);
        
        
       
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void ha4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseClicked
        mainPanel.removeAll();
        mainPanel.repaint();
        mainPanel.revalidate();
        
        //addpanel
        mainPanel.add(Data_Ekstrakurikuler);
        mainPanel.repaint();
        mainPanel.revalidate();
        setColor2(ha4);
        resetColor2(ha1);
        resetColor2(ha2);
        resetColor2(ha3);
        
    }//GEN-LAST:event_ha4MouseClicked

    private void ha4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseEntered
        // TODO add your handling code here:
        setColor(ha4);
    }//GEN-LAST:event_ha4MouseEntered

    private void ha4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MouseExited
        // TODO add your handling code here:
        resetColor(ha4);
    }//GEN-LAST:event_ha4MouseExited

    private void ha4MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ha4MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_ha4MousePressed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        // TODO add your handling code here:
        String id_siswa = txId_siswa2.getText();
        String nis = txNis.getText();
        String nama_siswa = txNama.getText();
        
        String tempat_lahir = txTl.getText();
        String tanggal_lahir = txTtl.getText();
        
        //String tanggal_lahir = ((JTextField)txTtl.getDateEditor().getUiComponent()).getText();
        //String tanggal_lahir = txTtl.getText();
        String alamat = txAlamat.getText();
        String kelas = (String) txKelas.getSelectedItem();
        String jurusan = (String) txJurusan.getSelectedItem();
        String rombel = (String) txGolongan.getSelectedItem();

        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "INSERT INTO siswa VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement p = c.prepareStatement(sql);
            p.setString(1, id_siswa);
            p.setString(2, nis);
            p.setString(3, nama_siswa);
            p.setString(4, tempat_lahir);
            
            p.setString(5 ,tanggal_lahir);
            p.setString(6, alamat);
            p.setString(7, kelas);
            p.setString(8, jurusan);
            p.setString(9, rombel);
            p.executeUpdate();
            p.close();
            JOptionPane.showMessageDialog(null, "Data Tersimpan");
            
        }catch(SQLException e){
            System.out.println("Terjadi Kesalahan");
        }finally{
            model = new DefaultTableModel();
        
            jTable1.setModel(model);
        
        
             model.addColumn("Nis");
             model.addColumn("Nama");
            model.addColumn("Tempat lahir");
                model.addColumn("Tanggal lahir");
        model.addColumn("Alamat");
        model.addColumn("Kelas");
        model.addColumn("Jurusan");
        model.addColumn("Golongan");
        loadData2();
            
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void txCari2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txCari2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txCari2ActionPerformed

    private void txCari2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txCari2KeyTyped
        // TODO add your handling code here:
        DefaultTableModel tabel2 = new DefaultTableModel();

        tabel2.addColumn("Nama Ekstrakurikuler");
        tabel2.addColumn("Penanggung jawab");
        tabel2.addColumn("Lokasi Ekskul");
        tabel2.addColumn("Hari");
        tabel2.addColumn("Jam Mulai");
        tabel2.addColumn("Jam Selesai");
        

        try{
            Connection c = Koneksi.getKoneksi();
            String sql = "Select * from ekskul where nama_ekskul like '%" + txCari2.getText() + "%'";
            Statement stat = c.createStatement();
            ResultSet rs = stat.executeQuery(sql);
            while(rs.next()){
                tabel2.addRow(new Object[]{
                    rs.getString(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6),
                    rs.getString(7),
                    
                });
            }
            jTable3.setModel(tabel2);
            
        }catch(Exception e){
            System.out.println("Cari Data Error");
        }finally{
        }
    }//GEN-LAST:event_txCari2KeyTyped

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        mainPanel.removeAll();
    
        mainPanel.repaint();
        mainPanel.revalidate();
        
        mainPanel.add(Input_data_pengguna);
        mainPanel.repaint();
        mainPanel.revalidate();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jLabel40MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel40MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabel40MouseClicked

    private void btnSimpan1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpan1ActionPerformed
        // TODO add your handling code here:
        String id_user = txId.getText().toString().trim();
        String id_siswa = (String) cbNis.getSelectedItem();
        String username = txUsername.getText().toString().trim();
        String password = txPassword.getText().toString().trim();
        String conPassword = txConPassword.getText().toString().trim();
        String role = (String) cbStatus.getSelectedItem();
        
        if(!password.equals(conPassword)){
            JOptionPane.showMessageDialog(null, "Password not match");
        }else if(password.equals("") || username.equals("")){
            JOptionPane.showMessageDialog(null, "Username or Password cannot be empty");
            
        }else{
            try{
            Connection c = Koneksi.getKoneksi();
            String sql ="INSERT INTO user VALUES (?,?,?,?,?)";
            PreparedStatement p = c.prepareStatement(sql);
            p.setString(1, id_user);
            p.setString(2, username);
            p.setString(3, password);
            p.setString(4, role);
            p.setString(5, id_siswa);
            p.executeUpdate();
            p.close();
            JOptionPane.showMessageDialog(null, "Create Account Successfully");
            
            
        }catch(SQLException e){
                System.out.println("Error");
        }finally{
            
        }
        }
    }//GEN-LAST:event_btnSimpan1ActionPerformed

    private void cbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbStatusActionPerformed

    private void txNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txNamaActionPerformed

    void setColor(JPanel panel){
        panel.setBackground(new Color(204,204,204));
    }
    void resetColor(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    
    void setColor2(JPanel panel){
        panel.setBackground(new Color(102,153,255));
    }
    void resetColor2(JPanel panel){
        panel.setBackground(new Color(60,60,60));
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormDasboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Data_Ekstrakurikuler;
    private javax.swing.JPanel Data_Pengguna;
    private javax.swing.JPanel Data_Siswa;
    private javax.swing.JPanel Input_data_pengguna;
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnSimpan1;
    private javax.swing.JComboBox<String> cbNis;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JPanel dashboard;
    private javax.swing.JPanel ha1;
    private javax.swing.JPanel ha2;
    private javax.swing.JPanel ha3;
    private javax.swing.JPanel ha4;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel sidepane;
    public javax.swing.JTextField txAlamat;
    private javax.swing.JTextField txCari;
    private javax.swing.JTextField txCari1;
    private javax.swing.JTextField txCari2;
    private javax.swing.JTextField txConPassword;
    public javax.swing.JComboBox<String> txGolongan;
    private javax.swing.JTextField txId;
    private javax.swing.JLabel txId1;
    private javax.swing.JLabel txId2;
    private javax.swing.JLabel txId3;
    private javax.swing.JTextField txId_siswa2;
    public javax.swing.JComboBox<String> txJurusan;
    public javax.swing.JComboBox<String> txKelas;
    public javax.swing.JTextField txNama;
    public javax.swing.JTextField txNis;
    private javax.swing.JTextField txPassword;
    public javax.swing.JTextField txTl;
    private javax.swing.JTextField txTtl;
    private javax.swing.JTextField txUsername;
    // End of variables declaration//GEN-END:variables
}
