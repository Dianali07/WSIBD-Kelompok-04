-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2021 at 07:16 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yu`
--

-- --------------------------------------------------------

--
-- Table structure for table `ekskul`
--

CREATE TABLE `ekskul` (
  `id_ekskul` int(11) NOT NULL,
  `nama_ekskul` varchar(50) NOT NULL,
  `penanggung_jawab` varchar(50) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `hari` enum('senin','selasa','rabu','kamis','jumat','sabtu','minggu') NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ekskul`
--

INSERT INTO `ekskul` (`id_ekskul`, `nama_ekskul`, `penanggung_jawab`, `lokasi`, `hari`, `jam_mulai`, `jam_selesai`) VALUES
(1, 'Pramuka', 'Andi', 'Lapangan 1', 'sabtu', '08:00:00', '10:00:00'),
(6, 'Osis', 'Jonny', 'lapangan bola volly', 'selasa', '15:00:00', '17:00:00'),
(7, 'Bola Volly', 'luluk', 'lapangan bola volly 1', 'kamis', '16:30:00', '08:00:00'),
(8, 'Parkour', 'izul', 'taman', 'selasa', '16:00:00', '18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `registrasi`
--

CREATE TABLE `registrasi` (
  `id_registrasi` int(11) NOT NULL,
  `id_ekskul` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `tanggal_daftar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrasi`
--

INSERT INTO `registrasi` (`id_registrasi`, `id_ekskul`, `id_siswa`, `tanggal_daftar`) VALUES
(4, 6, 8, '2021-07-08'),
(5, 6, 11, '2021-07-19'),
(6, 6, 24, '2021-07-19'),
(7, 6, 24, '2021-07-19'),
(8, 6, 24, '2021-07-19'),
(9, 6, 24, '2021-07-19'),
(10, 6, 24, '2021-07-19'),
(11, 6, 24, '2021-07-19'),
(12, 6, 24, '2021-07-20'),
(13, 6, 24, '2021-07-20'),
(14, 1, 7, '2021-07-20'),
(15, 6, 14, '2021-07-20'),
(16, 8, 8, '2021-07-20'),
(17, 7, 15, '2021-07-20'),
(18, 7, 25, '2021-07-20');

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nis` varchar(20) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `kelas` enum('10','11','12','') NOT NULL,
  `jurusan` enum('IPA','IPS','','') NOT NULL,
  `rombel` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nis`, `nama_siswa`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `kelas`, `jurusan`, `rombel`) VALUES
(2, 'E41200176', 'Feri Febrianto', 'Jombang', '2000-02-08', 'jombang, mancilan', '10', 'IPA', 'a'),
(7, 'E41200178', 'Dwi Ambarwati', 'Jombang', '2001-07-13', 'wonosalam', '10', 'IPA', '2'),
(8, 'E41200175', 'Astri Febrianingrum', 'jombang', '2002-02-08', 'sadsa', '11', 'IPS', '2'),
(10, 'sadas', 'dasa', 'sdasd', '2021-07-03', 'dasd', '12', 'IPA', '3'),
(11, '12314', 'sa321', '321', '2021-07-08', 'asda', '11', 'IPS', '2'),
(12, '2314sad', 'sadsad', 'asdas', '2021-07-16', 'sadasd', '11', 'IPS', '3'),
(13, '2314', 'asda', 'aseqw', '2021-07-02', 'asdas', '11', 'IPS', '2'),
(14, 'ewqewq', 'ewqewqewq', 'ewq', '2021-07-09', 'ewq', '11', 'IPA', '3'),
(15, 'eqwwq', 'ewqeq', 'ewqewq', '2021-07-16', 'eqweq', '11', 'IPA', '2'),
(16, 'sdasda', 'sadad', 'sada', '2021-07-01', 'dsadsa', '11', 'IPS', '3'),
(17, 'dsad', 'asdasd', 'asdads', '2021-07-08', 'dsada', '11', 'IPA', '3'),
(18, 'feri', 'fer', 'sda', '2021-07-15', 'dsa', '10', 'IPS', '3'),
(19, 'sabar', 'sabar', 'dsad', '2021-07-09', 'dassa', '11', 'IPS', '2'),
(20, 'sda', 'dsa', 'da', '2001-07-23', 'dsadsad', '11', 'IPA', 'A'),
(21, 'dsadsa', 'sdadsa', 'dsadsa', '2021-07-02', 'dsa', '10', 'IPS', '2'),
(22, 'sdasd', 'dsas', 'dsa', '2021-07-09', 'sad', '12', 'IPA', '2'),
(23, 'sda', 'dsa', 'dsa', '2021-07-08', 'das', '11', 'IPA', '3'),
(24, 'E41200178', 'Astri Febrianingrum', 'Jombang', '2002-02-08', 'jombang,mojoagung', '10', 'IPA', '5'),
(25, 'E4120067', 'Adam Dwi Julianto', 'Jombang', '2021-07-09', 'Jombang', '12', 'IPA', '2');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('0','1') NOT NULL,
  `id_siswa` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `role`, `id_siswa`) VALUES
(1, 'admin', 'admin', '1', 8),
(7, 'chaplin231', 'bontoro123', '0', 24),
(9, 'chaplin231', 'bontoro123', '0', 24),
(10, 'chaplin231', 'bontoro123', '0', 25);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ekskul`
--
ALTER TABLE `ekskul`
  ADD PRIMARY KEY (`id_ekskul`);

--
-- Indexes for table `registrasi`
--
ALTER TABLE `registrasi`
  ADD PRIMARY KEY (`id_registrasi`),
  ADD KEY `fk_registrasi_ekskul` (`id_ekskul`),
  ADD KEY `fk_registrasi_siswa` (`id_siswa`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `fk_siswa` (`id_siswa`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ekskul`
--
ALTER TABLE `ekskul`
  MODIFY `id_ekskul` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `registrasi`
--
ALTER TABLE `registrasi`
  MODIFY `id_registrasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `registrasi`
--
ALTER TABLE `registrasi`
  ADD CONSTRAINT `fk_registrasi_ekskul` FOREIGN KEY (`id_ekskul`) REFERENCES `ekskul` (`id_ekskul`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_registrasi_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
